<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="keywords" content="">
		<title>v1_beeline_adult</title>
		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet" type="text/css">
		<link media="all" rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="page">
			<div class="button-wrap">
				<form method="POST" action="../redirect.php?url=<?=$_GET['url']?>&abonent_id=<?=$_GET['abonent_id']?>" name="mainFrm">
					<button id="wapSubmitBtn" class="button" type="submit">
						<span>Смотреть</span>
					</button>
				</form>
				<div td:if="${useSmsLink == null || useSmsLink == 'false'}">
					<span class="price" td:switch="${evalRequestType}">
						<span td:case="'single-request'">
							<span td:if="${tarifficationType == 1 and cpaRequestPriceCodePrice != null}" td:text="'Стоимость: ' + ${cpaRequestPriceCodePrice} + ' руб.'" class="line2">Доступ: 30 руб. в день</span>
						</span>
					</span>
				</div>
			</div>
			<div class="header">
				<div class="header-wrap">
					<div class="wrapper">
						<div class="header-title">Эротика</div>
						<div class="header-subtitle">Сочная эротика в HD</div>
						<div class="header-age">18+</div>
					</div>
				</div>
			</div>
			<div class="main">
				<div class="main-wrap">
					<div class="wrapper">
						
					</div>
				</div>
			</div>
			
			<div class="footer">
				<div class="footer-wrap">
					<div class="text-regulations">
						<div>
							<span th:utext="${(#strings.arraySplit(partnerContact, ','))[0]}">ООО «Партнерские технологии»</span>
							<span th:utext="'Поддержка:' + ${(#strings.arraySplit(partnerContact, ','))[1]}">Поддержка: 8-800-555-39-76</span>
							<span th:utext="'e-mail:' + ${(#strings.arraySplit(partnerContact, ','))[2]}">e-mail: helpdesk@part-t.ru</span>
						</div>
						<a href="http://moskva.beeline.ru/customers/products/mobile/services/details/uslugi-na-korotkikh-nomerakh/">Пользовательское соглашение</a>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
